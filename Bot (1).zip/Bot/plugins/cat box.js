import fetch from 'node-fetch'
import FormData from 'form-data'

const UA = 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36'

const getSession = async () => {
  const res     = await fetch('https://imgbb.com/', {
    headers: { 'user-agent': UA, 'accept': 'text/html' }
  })
  const html    = await res.text()
  const cookies = res.headers.raw()['set-cookie'] || []
  const sessRaw = cookies.find(c => c.startsWith('PHPSESSID='))
  const sessId  = sessRaw ? sessRaw.split('=')[1].split(';')[0] : ''

  const patterns = [
    /auth_token["'\s:=]+([a-f0-9]{40})/,
    /"auth_token":"([a-f0-9]{40})"/,
    /PF\.obj\.set\("auth_token","([a-f0-9]{40})"\)/,
    /auth_token=([a-f0-9]{40})/,
  ]

  let authToken = ''
  for (const pattern of patterns) {
    const match = html.match(pattern)
    if (match?.[1] && match[1].length === 40) {
      authToken = match[1]
      break
    }
  }

  return { sessId, authToken }
}

const uploadWithSession = async (buffer, mime, sessId, authToken) => {
  let ext = 'jpg'
  if (mime.includes('png'))  ext = 'png'
  else if (mime.includes('gif'))  ext = 'gif'
  else if (mime.includes('webp')) ext = 'webp'
  else if (mime.includes('mp4'))  ext = 'mp4'

  const form = new FormData()
  form.append('source', buffer, { filename: `upload_${Date.now()}.${ext}`, contentType: mime })
  form.append('type', 'file')
  form.append('action', 'upload')
  form.append('timestamp', Date.now().toString())
  form.append('auth_token', authToken)

  const res  = await fetch('https://imgbb.com/json', {
    method: 'POST',
    body: form,
    headers: {
      ...form.getHeaders(),
      'user-agent': UA,
      'accept': 'application/json',
      'origin': 'https://imgbb.com',
      'referer': 'https://imgbb.com/',
      'cookie': `PHPSESSID=${sessId}`
    }
  })
  const data = await res.json()
  return data?.image?.url || data?.data?.url || null
}

const uploadTo0x0 = async (buffer, mime) => {
  let ext = 'jpg'
  if (mime.includes('png'))  ext = 'png'
  else if (mime.includes('gif'))  ext = 'gif'
  else if (mime.includes('webp')) ext = 'webp'
  else if (mime.includes('mp4'))  ext = 'mp4'

  const form = new FormData()
  form.append('file', buffer, { filename: `file.${ext}`, contentType: mime })

  const res  = await fetch('https://0x0.st', {
    method: 'POST',
    body: form,
    headers: { ...form.getHeaders(), 'user-agent': UA }
  })
  const link = (await res.text()).trim()
  return link.startsWith('https://') ? link : null
}

const uploadOne = async (buffer, mime, sessId, authToken) => {
  // جرب ImgBB أول
  if (authToken) {
    try {
      const link = await uploadWithSession(buffer, mime, sessId, authToken)
      if (link) return link
    } catch {}
  }
  // Fallback 0x0.st
  return await uploadTo0x0(buffer, mime)
}

// ════════════════════════════════════════════════════════
let handler = async (m, { conn }) => {
  // ✅ جمع كل الصور - من الرسالة الحالية أو الريبلاي
  const targets = []

  // لو ريبلاي على صورة
  if (m.quoted) {
    const qmime = m.quoted.mimetype || ''
    if (qmime.startsWith('image/') || qmime.startsWith('video/')) {
      targets.push(m.quoted)
    }
  }

  // لو الرسالة الحالية فيها صورة
  const mmime = m.mimetype || ''
  if (mmime.startsWith('image/') || mmime.startsWith('video/')) {
    targets.push(m)
  }

  if (targets.length === 0) {
    return m.reply(`╭─「 🖼️ *رفع صور* 」
│
│  ⚠️ ريبلاي على صورة أو فيديو!
│
│  📌 *طريقة الاستخدام:*
│  • ريبلاي على صورة واحدة + .catbox
│  • ابعت .catbox في نفس البوم
│
╰──────────────`)
  }

  await m.react('⏳')

  try {
    const { sessId, authToken } = await getSession()
    const links = []

    for (let i = 0; i < targets.length; i++) {
      const target = targets[i]
      const mime   = target.mimetype || ''

      try {
        await m.reply(`📤 جاري رفع الصورة ${i + 1} من ${targets.length}...`)
        const buffer = await target.download()
        const link   = await uploadOne(buffer, mime, sessId, authToken)

        if (link) {
          links.push({ num: i + 1, link })
        } else {
          links.push({ num: i + 1, link: '❌ فشل الرفع' })
        }
      } catch (e) {
        links.push({ num: i + 1, link: `❌ ${e.message.slice(0, 30)}` })
      }
    }

    const result = links.map(l => `│  *${l.num}.* ${l.link}`).join('\n')

    await m.react('✅')
    await m.reply(`╭─「 ✅ *تم الرفع* 」
│
${result}
│
╰──────────────`)

  } catch (e) {
    console.error('[Upload]', e.message)
    await m.react('❌')
    m.reply(`❌ خطأ: ${e.message}`)
  }
}

handler.help = ['catbox']
handler.tags = ['tools']
handler.command = /^cat\s?box$/i

export default handler