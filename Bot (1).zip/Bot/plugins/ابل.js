/**
 * plugins/ابل.js
 * بحث وتحميل من Apple Music — قوائم تفاعلية مثل مانجا
 * ✅ نسخة مُصلَّحة: session token + cookie flow
 */

import axios from 'axios';
import pkg   from '@whiskeysockets/baileys';
const { generateWAMessageFromContent, proto, prepareWAMessageMedia } = pkg;

const SPOTDOWN_BASE = 'https://spotdown.org';
const APPLE_TOKEN   = 'Bearer eyJhbGciOiJFUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IldlYlBsYXlLaWQifQ.eyJpc3MiOiJBTVBXZWJQbGF5IiwiaWF0IjoxNzcwODcxMjQ5LCJleHAiOjE3NzgxMjg4NDksInJvb3RfaHR0cHNfb3JpZ2luIjpbImFwcGxlLmNvbSJdfQ.7Zj7Zb4kkn7PUlTpFZxF5Fb1zv_WBRROmZuM3IBdvrkhkYzUs3eXyyiuhW_vbOXVeibrQVRjTnvU-Zr4v4w_Bg';
const UA            = 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36';
const FB_IMG        = 'https://i.postimg.cc/43Yt2ngB/Gojo-manga.jpg';

// ══════════════════════════════════════════════════
//  مساعدات
// ══════════════════════════════════════════════════
function fmtMs(ms) {
  if (!ms) return '0:00';
  const s = Math.floor(ms / 1000);
  return `${Math.floor(s / 60)}:${(s % 60).toString().padStart(2, '0')}`;
}

function normalizeSong(s) {
  return {
    title:      s.title      || s.name        || 'Unknown',
    artist:     s.artist     || s.author      || s.artistName || 'Unknown',
    cover:      s.thumbnail  || s.image       || s.artwork    || null,
    duration:   s.duration   || s.durationMs  || '',
    spotifyUrl: s.url        || s.spotify_url || s.spotifyUrl || null,
  };
}

// ══════════════════════════════════════════════════
//  الحصول على session token + cookie من Spotdown
// ══════════════════════════════════════════════════
async function getSpotdownSession() {
  const res = await axios.get(`${SPOTDOWN_BASE}/api/get-session-token`, {
    headers: {
      'accept':          '*/*',
      'accept-language': 'ar-EG,ar;q=0.9,en-GB;q=0.8',
      'referer':         `${SPOTDOWN_BASE}/`,
      'sec-ch-ua':       '"Chromium";v="139", "Not;A=Brand";v="99"',
      'sec-ch-ua-mobile':'?1',
      'sec-fetch-dest':  'empty',
      'sec-fetch-mode':  'cors',
      'sec-fetch-site':  'same-origin',
      'user-agent':      UA,
    },
    timeout: 15000,
  });

  const token = res.data?.token || res.data?.sessionToken || res.data;
  // استخراج الـ cookie من الـ response headers
  const setCookie = res.headers['set-cookie'] || [];
  const cookie = setCookie
    .map(c => c.split(';')[0])
    .join('; ');

  if (!token) throw new Error('فشل الحصول على session token');
  return { token: String(token).trim(), cookie };
}

// ══════════════════════════════════════════════════
//  Apple Music Search
// ══════════════════════════════════════════════════
async function searchApple(query) {
  const res = await axios.get(
    'https://amp-api-edge.music.apple.com/v1/catalog/us/search',
    {
      params:  { term: query, types: 'songs', limit: 8 },
      headers: {
        'authority':       'amp-api-edge.music.apple.com',
        'accept':          '*/*',
        'accept-language': 'ar-EG,ar;q=0.9,en-GB;q=0.8',
        'authorization':   APPLE_TOKEN,
        'origin':          'https://music.apple.com',
        'referer':         'https://music.apple.com/',
        'user-agent':      UA,
      },
      timeout: 15000,
    }
  );
  return res.data?.results?.songs?.data || [];
}

// ══════════════════════════════════════════════════
//  Spotdown: Apple URL → بيانات + Spotify URL
// ══════════════════════════════════════════════════
async function getSongDetails(appleUrl) {
  const { token, cookie } = await getSpotdownSession();

  const headers = {
    'accept':          'application/json, text/plain, */*',
    'accept-language': 'ar-EG,ar;q=0.9,en-GB;q=0.8',
    'referer':         `${SPOTDOWN_BASE}/`,
    'sec-ch-ua':       '"Chromium";v="139", "Not;A=Brand";v="99"',
    'sec-ch-ua-mobile':'?1',
    'sec-fetch-dest':  'empty',
    'sec-fetch-mode':  'cors',
    'sec-fetch-site':  'same-origin',
    'user-agent':      UA,
    'x-session-token': token,
    ...(cookie ? { cookie } : {}),
  };

  const res = await axios.get(`${SPOTDOWN_BASE}/api/song-details`, {
    params:         { url: appleUrl },
    headers,
    timeout:        25000,
    validateStatus: () => true,
  });

  console.log('[Spotdown] song-details status:', res.status);

  if (res.status !== 200 || !res.data)
    throw new Error(`song-details أعاد ${res.status}`);

  const data = res.data;
  const songs = data?.songs || data?.data || data?.tracks || data?.results ||
    (Array.isArray(data) ? data : null);

  if (songs?.length) return { song: normalizeSong(songs[0]), token, cookie };
  if (data?.title || data?.name || data?.url)
    return { song: normalizeSong(data), token, cookie };

  throw new Error('لا توجد بيانات أغنية في الاستجابة');
}

// ══════════════════════════════════════════════════
//  Fallback: Odesli → Spotify URL
// ══════════════════════════════════════════════════
async function odesliGetSpotify(appleUrl) {
  const res = await axios.get('https://api.song.link/v1-alpha.1/links', {
    params:         { url: appleUrl, userCountry: 'US' },
    timeout:        20000,
    validateStatus: () => true,
  });
  if (res.status !== 200) throw new Error(`Odesli ${res.status}`);
  const spotUrl = res.data?.linksByPlatform?.spotify?.url;
  if (!spotUrl) throw new Error('Odesli: ما لقى Spotify URL');
  const entity  = res.data?.entitiesByUniqueId;
  const firstId = entity ? Object.keys(entity)[0] : null;
  const meta    = firstId ? entity[firstId] : {};
  return {
    title:      meta.title      || 'Unknown',
    artist:     meta.artistName || 'Unknown',
    cover:      meta.thumbnailUrl || null,
    duration:   '',
    spotifyUrl: spotUrl,
  };
}

// ══════════════════════════════════════════════════
//  Spotdown: Spotify URL → Buffer MP3
// ══════════════════════════════════════════════════
async function downloadSong(spotifyUrl, token, cookie) {
  const headers = {
    'accept':          'application/json, text/plain, */*',
    'accept-language': 'ar-EG,ar;q=0.9,en-GB;q=0.8',
    'content-type':    'application/json',
    'origin':          SPOTDOWN_BASE,
    'referer':         `${SPOTDOWN_BASE}/`,
    'sec-ch-ua':       '"Chromium";v="139", "Not;A=Brand";v="99"',
    'sec-ch-ua-mobile':'?1',
    'sec-fetch-dest':  'empty',
    'sec-fetch-mode':  'cors',
    'sec-fetch-site':  'same-origin',
    'user-agent':      UA,
    'x-session-token': token,
    ...(cookie ? { cookie } : {}),
  };

  const res = await axios.post(
    `${SPOTDOWN_BASE}/api/download`,
    { url: spotifyUrl },
    {
      headers,
      responseType:     'arraybuffer',
      timeout:          120000,
      maxContentLength: 100 * 1024 * 1024,
      validateStatus:   () => true,
    }
  );

  if (res.status !== 200) throw new Error(`download أعاد ${res.status}`);

  const buf = Buffer.from(res.data);
  const isMP3 =
    (buf[0] === 0x49 && buf[1] === 0x44 && buf[2] === 0x33) ||
    (buf[0] === 0xFF && (buf[1] & 0xE0) === 0xE0);

  if (!isMP3 || buf.length < 10000)
    throw new Error(`الملف مش MP3 صحيح (${buf.length} bytes)`);

  console.log('[Spotdown] ✅ تم التحميل:', (buf.length / 1024 / 1024).toFixed(2), 'MB');
  return buf;
}

// ══════════════════════════════════════════════════
//  تحميل كامل من Apple URL
// ══════════════════════════════════════════════════
async function fullDownload(conn, m, appleUrl) {
  let loadMsg;
  try {
    loadMsg = await conn.sendMessage(m.chat, { text: '🔍 جاري جلب بيانات الأغنية...' }, { quoted: m });
    const edit = (t) => conn.sendMessage(m.chat, { text: t, edit: loadMsg.key }).catch(() => {});

    let song, sessionToken, sessionCookie;

    // المرحلة 1: جلب البيانات
    try {
      const result = await getSongDetails(appleUrl);
      song          = result.song;
      sessionToken  = result.token;
      sessionCookie = result.cookie;
      console.log('[Apple] ✅ song-details نجح:', song.title);
    } catch (detailsErr) {
      console.warn('[Apple] ⚠️ getSongDetails فشل:', detailsErr.message);
      await edit('⚠️ مسار Spotdown غير متاح، جاري تجربة Odesli...');
      try {
        song = await odesliGetSpotify(appleUrl);
        // نحتاج session جديدة للـ download
        const session = await getSpotdownSession();
        sessionToken  = session.token;
        sessionCookie = session.cookie;
        console.log('[Apple] ✅ Odesli نجح:', song.title);
      } catch (odesliErr) {
        const raw = decodeURIComponent(appleUrl.split('/').slice(-1)[0].split('?')[0]);
        song = { title: raw.replace(/-/g, ' ') || 'Unknown', artist: 'Unknown', cover: null, duration: '', spotifyUrl: null };
      }
    }

    // المرحلة 2: التحميل
    if (!song.spotifyUrl)
      throw new Error('تعذّر الحصول على رابط التحميل.\nتأكد أن الرابط صحيح أو جرّب رابطاً آخر.');

    await edit(`🍎 *${song.title}*\n👤 ${song.artist}\n📥 جاري التحميل...`);
    const buf = await downloadSong(song.spotifyUrl, sessionToken, sessionCookie);

    // المرحلة 3: الإرسال
    const caption = [`🎵 *${song.title}*`, `👤 ${song.artist}`, song.duration ? `⏱ ${song.duration}` : null]
      .filter(Boolean).join('\n');

    await conn.sendMessage(m.chat, {
      audio:    buf,
      mimetype: 'audio/mpeg',
      fileName: `${song.title} - ${song.artist}.mp3`,
      caption,
    }, { quoted: m });

    if (song.cover) {
      try {
        const img = await axios.get(song.cover, { responseType: 'arraybuffer', timeout: 15000 });
        await conn.sendMessage(m.chat, { image: Buffer.from(img.data), caption: `🖼️ ${song.title}` }, { quoted: m });
      } catch (_) {}
    }

    await m.react('✅');

  } catch (e) {
    console.error('[Apple DL]', e.message);
    await m.react('❌');
    await m.reply(`❌ *فشل التحميل*\n\n⚠️ ${e.message}`).catch(() => {});
  }
}

// ══════════════════════════════════════════════════
//  إرسال قائمة نتائج البحث
// ══════════════════════════════════════════════════
async function sendSearchList(conn, m, songs, query, pre, cmd) {
  const firstSong = songs[0].attributes;
  const aw        = firstSong.artwork;
  const coverUrl  = aw ? aw.url.replace('{w}', '600').replace('{h}', '600') : FB_IMG;

  const bodyText = songs.map((s, i) => {
    const a = s.attributes;
    return `*${i + 1}. ${a.name}*\n   👤 ${a.artistName}  •  ⏱ ${fmtMs(a.durationInMillis)}`;
  }).join('\n\n');

  const sections = [{
    title: `🎵 نتائج البحث (${songs.length})`,
    rows: songs.map((s, i) => {
      const a = s.attributes;
      return {
        header:      `${i + 1}. ${a.name}`,
        title:       a.artistName,
        description: `⏱ ${fmtMs(a.durationInMillis)}  •  💿 ${a.albumName}`,
        id:          `${pre}${cmd} --url ${encodeURIComponent(a.url)}`,
      };
    }),
  }];

  try {
    const media = await prepareWAMessageMedia({ image: { url: coverUrl } }, { upload: conn.waUploadToServer });
    const msg   = generateWAMessageFromContent(m.chat, {
      viewOnceMessage: { message: { interactiveMessage: proto.Message.InteractiveMessage.create({
        body:   proto.Message.InteractiveMessage.Body.create({ text: `🔍 *نتائج البحث في Apple Music*\n🎤 ${query}\n\n${bodyText}` }),
        footer: proto.Message.InteractiveMessage.Footer.create({ text: '🍎 اختر أغنية لتحميلها' }),
        header: proto.Message.InteractiveMessage.Header.create({ title: '🍎 Apple Music', hasMediaAttachment: true, imageMessage: media.imageMessage }),
        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
          buttons: [{ name: 'single_select', buttonParamsJson: JSON.stringify({ title: '🎵 اختر أغنية', sections }) }],
        }),
      })}}
    }, { userJid: m.sender, quoted: m });
    return conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
  } catch (e) {
    const txt = songs.map((s, i) => {
      const a = s.attributes;
      return `*${i + 1}. ${a.name}* — ${a.artistName}\n${pre}${cmd} --url ${encodeURIComponent(a.url)}`;
    }).join('\n\n');
    return m.reply(`🎵 *نتائج البحث*\n\n${txt}`);
  }
}

// ══════════════════════════════════════════════════
//  Handler الرئيسي
// ══════════════════════════════════════════════════
const handler = async (m, { conn, text, usedPrefix, command }) => {
  const input = (text || '').trim();

  if (!input) {
    return m.reply(
      `🍎 *Apple Music Bot*\n\n` +
      `*بحث:*\n${usedPrefix}${command} اسم الأغنية\n\n` +
      `*تحميل مباشر:*\n${usedPrefix}${command} رابط Apple Music\n\n` +
      `*مثال:*\n${usedPrefix}${command} shape of you\n` +
      `${usedPrefix}${command} https://music.apple.com/us/album/batidao/1862790500?i=1862790502`
    );
  }

  const flags  = {};
  const flagRx = /--(\w+)\s+((?:(?!--).)+)/g;
  let   fx;
  while ((fx = flagRx.exec(input)) !== null) flags[fx[1]] = fx[2].trim();

  if (flags.url) {
    await m.react('🍎');
    return fullDownload(conn, m, decodeURIComponent(flags.url));
  }

  if (/music\.apple\.com/i.test(input)) {
    await m.react('🍎');
    return fullDownload(conn, m, input);
  }

  const query = input.replace(/--\w+\s+(?:(?!--).)+/g, '').trim();
  if (!query) return m.reply('❌ اكتب اسم الأغنية بعد الأمر');

  await m.react('🎵');

  try {
    await m.reply(`🔍 جاري البحث عن:\n"${query}"`);
    const songs = await searchApple(query);
    if (!songs.length) { await m.react('❌'); return m.reply('❌ *لم يتم العثور على نتائج*'); }
    await sendSearchList(conn, m, songs, query, usedPrefix, command);
    await m.react('✅');
  } catch (e) {
    console.error('[Apple Search]', e.message);
    await m.react('❌');
    let msg = '❌ *حدث خطأ أثناء البحث*\n\n';
    if (e.response?.status === 401) msg += '🔐 انتهت صلاحية المصادقة.';
    else if (e.response?.status === 429) msg += '⏳ تجاوزت الحد المسموح، حاول بعد قليل.';
    else msg += `⚠️ ${e.message}`;
    await m.reply(msg);
  }
};

handler.help    = ['ابل <اسم أغنية أو رابط>'];
handler.tags    = ['downloader'];
handler.command = /^(ابل|apple|applemusic|ابلميوزك)$/i;

export default handler;