import fetch from "node-fetch";

let handler = async (m, { conn, text }) => {
  if (!text)
    return m.reply(
      "👹 ادم:* أنت تحاول تلعبها ذكي؟ أرسل لي السؤال بدقة.\n\nمثال:\n⟣ .سكونا ما رأيك في ادم ⟣"
    );

  await m.reply("⛩️ ادم:* اهتم... سأقرر إذا أرد عليك أم أتركك للحظك القاسي ⛩️");

  try {
    let result = await CleanSukona(text);
    await m.reply(
      `*╭─━━━───✦━━━───╮*\n⛩️ *الملك ادم قال:*\n『 ${result} 』\n*╰─━━━───✦━━━───╯*`
    );
  } catch (e) {
    await m.reply("⛩️ *ادم:* حتى أنا أملّ أحيانًا من البشر السخيفين ⛩️");
  }
};

handler.help = ["sukuna"];
handler.tags = ["ai"];
handler.command = /^(ادم)$/i;

export default handler;

async function CleanSukona(your_qus) {
  let Baseurl = "https://alakreb.vercel.app/api/ai/gpt?q=";

  // أسلوب سوكونا الحقيقي: شرير، مباشر، ذكي، قليل المزاح
  let prompt = `
أنت "ريو سوكونا" من أنمي جوجوتسو كايسن.
ردّ على سؤالي وكأنك سوكونا بنفسك:
- استخدم أسلوبًا شريرًا، مباشرًا، ذكي جدًا، قليل المزاح.
- أظهر الهيبة والقوة والهيمنة، بدون مبالغة سخيفة.
- أضف لمسات شخصية تبرز شره وكاريزمته.
السؤال هو: ${your_qus}
`;

  let response = await fetch(Baseurl + encodeURIComponent(prompt));
  let data = await response.json();
  return data.message;
}