// • Feature : TikTok EDIT Search (Single Video - No Carousel)
// • Developers : izana x radio
// • Channel : izana x radio

import fetch from "node-fetch";
import pkg from "@whiskeysockets/baileys";
const { generateWAMessageContent } = pkg;

const handler = async (m, { conn, args, usedPrefix, command }) => {
  try {
    if (!args[0]) {
      return conn.reply(
        m.chat,
        `[❗️] استخدم الأمر هكذا:
${usedPrefix}${command} <كلمة>
مثال: ${usedPrefix}${command} naruto`,
        m
      );
    }

    // البحث دائمًا بطريقة (edit + المطلوب)
    const fullQuery = `edit ${args.join(" ")}`;
    const apiUrl = `https://dark-api-x.vercel.app/api/v1/search/tiktok?text=${encodeURIComponent(fullQuery)}`;

    await conn.reply(m.chat, `⏳ جاري البحث عن *${fullQuery}* ...`, m);

    const res = await fetch(apiUrl);
    const data = await res.json();

    if (!data.status || !data.videos || data.videos.length === 0) {
      return conn.reply(m.chat, `❌ لا توجد نتائج لـ: *${fullQuery}*`, m);
    }

    // أول نتيجة فقط
    const video = data.videos[0];

    await conn.sendMessage(
      m.chat,
      {
        video: { url: video.play },
        caption: `🎬 *نتيجة EDIT*\n\n▶️ العنوان: ${video.title || "بدون عنوان"}\n🔎 البحث: ${fullQuery}`
      },
      { quoted: m }
    );

  } catch (err) {
    console.error(err);
    conn.reply(m.chat, `❌ خطأ أثناء تشغيل أمر edit!\n\n${err}`, m);
  }
};

handler.help = ["ايديت <بحث>"];
handler.tags = ["downloader"];
handler.command = /^ايديت$/i;

export default handler;