import fetch from "node-fetch";

let handler = async (m, { conn }) => {
  const replyText = `
*✦ ━━━━━━━━━━━━━━━━━✦*

 𝔸𝔻𝔸𝕄 𝔹𝕆𝕋 🔥👌

*✦━━━━━━━━━━━━━━━━━✦*

*⚜️ | الاسم :* ادم
*👑 | اللقب :* زوج العديد من النساء ويمكن انتي تكوني منهم
*⚡ | طولو  :* 40cm

━━━━━━━━━━━━━━━━━━

*❝ اركع أمامي وأثبت أنك تستحق الموت على يدي ❞*

   🩸 *𝑾𝒆𝒍𝒄𝒐𝒎𝒆 𝒕𝒐 𝒎𝒚 𝒅𝒐𝒎𝒂𝒊𝒏* 🩸

*✦ ━━━━━━━━━━━━━━━ ✦*
`;

  const imageUrl = "https://files.catbox.moe/5qin29.jpg";

  try {
    const response = await fetch(imageUrl);
    if (!response.ok) throw new Error("فشل تحميل الصورة");
    const imageBuffer = Buffer.from(await response.arrayBuffer());

    await conn.sendMessage(
      m.chat,
      { image: imageBuffer, caption: replyText },
      { quoted: m }
    );
  } catch (err) {
    await conn.sendMessage(
      m.chat,
      { text: `⚠️ حدث خطأ: ${err.message}` },
      { quoted: m }
    );
  }
};

handler.customPrefix = /^(تست|\.تست)$/i;
handler.command = new RegExp();

export default handler;