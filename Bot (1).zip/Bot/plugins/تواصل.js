// plugins/تواصل.js

let handler = async (m, { conn }) => {
  await conn.sendMessage(m.chat, {
    contacts: {
      displayName: '👑 المطور',
      contacts: [
        {
          vcard: `BEGIN:VCARD\nVERSION:3.0\nFN:👑 عمو ادم\nTEL;type=CELL;type=VOICE;waid=22793142546:+22793142546 7166\nEND:VCARD`
        },
        {
          vcard: `BEGIN:VCARD\nVERSION:3.0\nFN:👑 عمو ادم 2\nTEL;type=CELL;type=VOICE;waid=201150572826:+2011 5057 2826 2826\nEND:VCARD`
        }
      ]
    }
  }, { quoted: m })

  await conn.sendMessage(m.chat, {
    text: `╭─「 ⛩️ *تواصل مع المطور* 」
│
│  🧠 *عمو مهاب* — صانع البوت
│
│  📲 *الرقم الأول:* +2011 5057 2826
│  📲 *الرقم التاني:* ++22793142546
│
│  ✨ *خد وكلم فحلك!*
│  🔧 هيحل أي مشكلة في ثواني
│
╰──────────────`
  }, { quoted: m })
}

handler.help = ['تواصل']
handler.tags = ['main']
handler.command = ['تواصل']

export default handler