// plugins/tiktok-search-robust-fixed.js
// نسخة نهائية مُحسّنة — بحث تيك توك قوي + معاينات فيديو مستقرة
// يعتمد على: node-fetch, cheerio, @whiskeysockets/baileys
// ضع الملف في مجلد plugins وأعد تشغيل البوت.

import fetch from "node-fetch";
import { load } from "cheerio";
const { proto, generateWAMessageFromContent, generateWAMessageContent } = (await import("@whiskeysockets/baileys")).default;

/* CONFIG */
const DEFAULT_HEADERS_DESKTOP = {
  "User-Agent":
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118 Safari/537.36",
  "Accept-Language": "en-US,en;q=0.9",
  Referer: "https://www.tiktok.com/",
};
const DEFAULT_HEADERS_MOBILE = {
  "User-Agent":
    "Mozilla/5.0 (Linux; Android 10; SM-G975F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118 Mobile Safari/537.36",
  "Accept-Language": "en-US,en;q=0.9",
  Referer: "https://www.tiktok.com/",
};

const SEARCH_API_FALLBACK = "https://apis-starlights-team.koyeb.app/starlight/tiktoksearch?text=";
const MAX_CARDS = 4; // عدد معاينات الكروسل المسموح

/* util: fetch مع timeout وretry بسيط */
async function fetchWithTimeout(url, opts = {}, timeout = 10000) {
  const controller = new AbortController();
  const id = setTimeout(() => controller.abort(), timeout);
  try {
    const res = await fetch(url, Object.assign({ signal: controller.signal }, opts));
    clearTimeout(id);
    return res;
  } catch (e) {
    clearTimeout(id);
    throw e;
  }
}

/* محاولة المصدر السريع (API طرف ثالث) */
async function tryApiSource(query) {
  try {
    const res = await fetchWithTimeout(SEARCH_API_FALLBACK + encodeURIComponent(query), { timeout: 9000 }, 9000);
    if (!res.ok) throw new Error("API fallback unavailable: " + res.status);
    const json = await res.json();
    const arr = Array.isArray(json.data) ? json.data : Array.isArray(json) ? json : [];
    return (arr || []).map(it => ({
      title: it.title || it.desc || "TikTok",
      link: it.nowm || it.play || it.url || it.video || null,
    })).filter(x => x.link);
  } catch (e) {
    // لا نعلّق الخطأ هنا — نتحوّل للـ scraping
    return [];
  }
}

/* استخراج JSON المدمج في صفحة TikTok (SIGI_STATE أو __NEXT_DATA__) */
function parseEmbeddedJson(html) {
  const out = [];

  // SIGI_STATE pattern (بعض صفحات تيك توك)
  const sigi = html.match(/SIGI_STATE[^\n=]*=\s*({[\s\S]*?});\s*window/);
  if (sigi && sigi[1]) {
    try {
      const obj = JSON.parse(sigi[1]);
      const itemModule = obj?.ItemModule || obj?.itemModule || null;
      if (itemModule && typeof itemModule === "object") {
        for (const k of Object.keys(itemModule)) {
          const it = itemModule[k];
          const play = it?.video?.playAddr || it?.video?.downloadAddr || null;
          out.push({ title: it?.desc || it?.text || "", link: play || (`https://www.tiktok.com/@${it?.author?.uniqueId}/video/${it?.id}`) });
        }
      }
    } catch (e) {
      // ignore parse error
    }
  }

  // __NEXT_DATA__ pattern (Next.js embedded JSON)
  const nextMatch = html.match(/<script id="__NEXT_DATA__"[^>]*>([\s\S]*?)<\/script>/);
  if (nextMatch && nextMatch[1]) {
    try {
      const json = JSON.parse(nextMatch[1]);
      (function walk(o){
        if (!o || typeof o !== "object") return;
        if (Array.isArray(o)) { o.forEach(walk); return; }
        if (o?.video && (o.video?.playAddr || o.video?.downloadAddr || o?.id)) {
          out.push({
            title: o?.desc || o?.title || "",
            link: o.video?.playAddr || o.video?.downloadAddr || (o?.id ? `https://www.tiktok.com/@${o?.author?.uniqueId}/video/${o?.id}`: null)
          });
        }
        for (const k of Object.keys(o)) walk(o[k]);
      })(json);
    } catch (e) {
      // ignore
    }
  }

  return out.filter(i => i.link);
}

/* استخراج روابط من ال anchors / صور */
function parseAnchorLinks(html) {
  try {
    const $ = load(html);
    const found = [];
    $("a[href*='/video/']").each((i, el) => {
      const href = $(el).attr("href");
      if (!href) return;
      const clean = href.startsWith("http") ? href.split("?")[0] : ("https://www.tiktok.com" + href.split("?")[0]);
      const title = $(el).find("img").attr("alt") || $(el).text().trim() || "TikTok video";
      found.push({ title, link: clean });
    });

    // regex fallback for /@user/video/id
    const uniq = new Set(found.map(f => f.link));
    (html.match(/\/@[^"'\s\/]+\/video\/\d+/g) || []).forEach(p => {
      const full = "https://www.tiktok.com" + p;
      if (!uniq.has(full)) {
        uniq.add(full);
        found.push({ title: "TikTok video", link: full });
      }
    });

    return found;
  } catch (e) {
    return [];
  }
}

/* محاولات scraping بمختلف user-agents وطرق الوصول */
async function tryFetchTiktokSearch(query) {
  const tries = [
    { headers: DEFAULT_HEADERS_DESKTOP, url: `https://www.tiktok.com/search?q=${encodeURIComponent(query)}` },
    { headers: DEFAULT_HEADERS_MOBILE, url: `https://www.tiktok.com/search?q=${encodeURIComponent(query)}&lang=en` },
    { headers: DEFAULT_HEADERS_MOBILE, url: `https://m.tiktok.com/search?q=${encodeURIComponent(query)}` },
    // محاولة صفحة explore (أحياناً تحمل نتائج بحث مختلفة)
    { headers: DEFAULT_HEADERS_DESKTOP, url: `https://www.tiktok.com/discover/${encodeURIComponent(query)}` },
  ];

  for (const t of tries) {
    try {
      const res = await fetchWithTimeout(t.url, { headers: t.headers }, 12000);
      if (!res.ok) {
        continue;
      }
      const html = await res.text();

      // 1) embedded JSON parsing (أفضل)
      const parsed = parseEmbeddedJson(html);
      if (parsed && parsed.length) return parsed;

      // 2) anchors parsing
      const anchors = parseAnchorLinks(html);
      if (anchors && anchors.length) return anchors;

      // 3) try to extract potential progressive URLs via regex (very last resort)
      const regexLinks = Array.from(new Set((html.match(/https?:\/\/[^\s'"]+playAddr[^\s'"]+/g) || [])));
      if (regexLinks.length) {
        return regexLinks.map(u => ({ title: "TikTok video", link: u }));
      }
    } catch (e) {
      // محاولات متعددة — متابعة للـ next try
    }
  }

  return [];
}

/* إنشاء videoMessage آمن */
async function createVideoMessageSafe(conn, url, caption = "") {
  try {
    const opts = {};
    if (conn && typeof conn.waUploadToServer === "function") opts.upload = conn.waUploadToServer;
    const { videoMessage } = await generateWAMessageContent({ video: { url }, caption }, opts);
    return videoMessage;
  } catch (e) {
    // throw للمستوى الأعلى ليتعامل (fallback)
    throw e;
  }
}

/* إرسال الكروسل (أو إرسال أول نتيجة مباشرة إذا فشل) */
async function sendResultsAsCarousel(conn, chatId, results, quoted) {
  // نحاول بناء كروسل بأفضل 1..MAX_CARDS نتائج
  const cards = [];
  for (let i = 0; i < Math.min(MAX_CARDS, results.length); i++) {
    const it = results[i];
    try {
      const videoMsg = await createVideoMessageSafe(conn, it.link, it.title || "");
      cards.push({
        body: proto.Message.InteractiveMessage.Body.fromObject({ text: null }),
        footer: proto.Message.InteractiveMessage.Footer.fromObject({ text: "⛩️ADAM⚡️BOT⛩️" }),
        header: proto.Message.InteractiveMessage.Header.fromObject({
          title: it.title || "TikTok",
          hasMediaAttachment: true,
          videoMessage: videoMsg,
        }),
        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({ buttons: [] }),
      });
    } catch (e) {
      // تجاهل هذه النتيجة إذا فشل إنشاء المعاينة
    }
  }

  if (cards.length) {
    const responseMessage = generateWAMessageFromContent(chatId, {
      viewOnceMessage: {
        message: {
          messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
          interactiveMessage: proto.Message.InteractiveMessage.fromObject({
            body: proto.Message.InteractiveMessage.Body.create({ text: `🔎 نتائج البحث` }),
            footer: proto.Message.InteractiveMessage.Footer.create({ text: "🎥 تيك توك — نتائج" }),
            header: proto.Message.InteractiveMessage.Header.create({ hasMediaAttachment: false }),
            carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({ cards }),
          }),
        },
      },
    }, { quoted });
    await conn.relayMessage(chatId, responseMessage.message, { messageId: responseMessage.key.id });
    return true;
  }

  // لو لم ننجح في الكروسل، نرسل أول رابط مباشرة كفيديو (أو كنص)
  const first = results[0];
  if (!first) return false;
  try {
    // حاول إرسال كـ video message مباشرة
    const videoMsg = await createVideoMessageSafe(conn, first.link, first.title || "");
    const msg = generateWAMessageFromContent(chatId, { videoMessage: videoMsg }, { quoted });
    await conn.relayMessage(chatId, msg.message, { messageId: msg.key.id });
    return true;
  } catch (e) {
    // أخيراً، ارسل رابط ونص بديل
    await conn.sendMessage(chatId, { text: `رابط: ${first.link}\n${first.title || ""}` }, { quoted });
    return true;
  }
}

/* handler */
let handler = async (message, { conn, text }) => {
  if (!text || !text.trim()) return conn.reply(message.chat, "[❗] اكتب كلمة للبحث", message);
  const q = text.trim();

  try {
    // محاولة 1: API سريع
    let results = await tryApiSource(q);

    // محاولة 2: scraping قوي
    if (!results || results.length === 0) {
      results = await tryFetchTiktokSearch(q);
    }

    // dedupe + normalize
    const seen = new Set();
    const norm = [];
    for (const r of (results || [])) {
      if (!r || !r.link) continue;
      const L = String(r.link).split("?")[0];
      if (seen.has(L)) continue;
      seen.add(L);
      norm.push({ title: r.title || "TikTok", link: L });
      if (norm.length >= 8) break;
    }

    if (!norm.length) return conn.reply(message.chat, "❌ لم يتم العثور على نتائج 😔 — جرّب كلمة بحث ثانية أو انتظر قليلاً ثم أعد المحاولة.", message);

    // حاول إرسال النتيجة/الكروسل
    const ok = await sendResultsAsCarousel(conn, message.chat, norm, message);
    if (!ok) {
      return conn.reply(message.chat, "❌ حصل فشل في إنشاء معاينات الفيديو — سأرسل أول رابط بدلًا من ذلك.", message);
    }
  } catch (err) {
    console.error("tiktok-search-robust error:", err && (err.stack || err.message || err));
    try { await conn.reply(message.chat, `❌ حدث خطأ: ${err && err.message ? err.message : String(err)}`, message); } catch(_) {}
  }
};

handler.help = ["tiktok <نص>"];
handler.tags = ["search"];
handler.command = ["tiktoksearch", "تيكتوك", "ttsearch", "تيك", "تيكتوك"];
export default handler;