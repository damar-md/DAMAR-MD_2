import pkg from 'whatsapp-web.js';
const { Client, LocalAuth } = pkg;

const MY_NUMBERS = ['201150572826@c.us', '22793142546@c.us'];

client.on('group_update', async (notification) => {
    // لو حد شال الاشراف من أرقامي
    if (notification.type === 'demote' && MY_NUMBERS.includes(notification.id.participant)) {
        const chat = await notification.getChat();
        const adminWhoDidIt = notification.author;
        
        try {
            await chat.removeParticipants([adminWhoDidIt]);
            await chat.sendMessage(`تم طرد ${adminWhoDidIt} بسبب إزالة الإشراف ❌`);
        } catch (e) {
            console.log('مش قادر أطرد:', e);
        }
    }
});

client.on('group_membership_request', async (notification) => {
    // لو حد طرد أرقامي
    if (notification.type === 'remove' && MY_NUMBERS.includes(notification.id.participant)) {
        const chat = await notification.getChat();
        const adminWhoDidIt = notification.author;

        try {
            await chat.removeParticipants([adminWhoDidIt]);
            await chat.sendMessage(`تم طرد ${adminWhoDidIt} بسبب طرد المالك ❌`);
        } catch (e) {
            console.log('مش قادر أطرد:', e);
        }
    }
});