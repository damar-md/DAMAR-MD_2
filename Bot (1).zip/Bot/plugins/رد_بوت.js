-import fetch from 'node-fetch'

let handler = async (m, { conn }) => {
  try {
    let audioUrl = 'https://raw.githubusercontent.com/RADIOdemon6-alt/uploading-/main/uploads/upload-1749647493385.opus'
    let thumbnailUrl = 'https://raw.githubusercontent.com/RADIOdemon6-alt/uploading-/main/uploads/upload-1749647683251.jpg'

    let res = await fetch(thumbnailUrl)
    if (!res.ok) throw new Error(`فشل تحميل الصورة: ${res.statusText}`)

    let thumbnail = Buffer.from(await res.arrayBuffer())

    await conn.sendMessage(m.chat, {
      audio: { url: audioUrl },
      mimetype: 'audio/mp4', // استخدم 'audio/ogg; codecs=opus' لو الصوت بصيغة opus حقيقية
      ptt: true,
      fileName: 'ADAM.mp3',
      contextInfo: {
        externalAdReply: {
          title: "🚫┇≡ ◡̈⃝⚰️•⪼ 𝑨𝑫𝑨𝑴 𝑻𝑯𝑬 𝑮𝑶𝑨𝑻",
          body: "🎤┇≡ ◡̈⃝🎼•⪼ 𝑨𝑫𝑨𝑴 𝑩𝑶𝑻",
          thumbnail,
          mediaType: 1,
          renderLargerThumbnail: true,
          mediaUrl: "https://wa.me/201150572826",
          sourceUrl: "https://wa.me/201150572826"
        }
      }
    }, {
      quoted: m,
      buttons: [
        { buttonId: '.الاوامر', buttonText: { displayText: '🧾 عرض الأوامر' }, type: 1 }
      ],
      headerType: 1
    })
  } catch (err) {
    console.error(err)
    m.reply('❌ حدث خطأ أثناء إرسال الرد الصوتي.')
  }
}

handler.customPrefix = /^(بوت|يا بوت)$/i
handler.command = new RegExp // يسمح له بالعمل دون أمر صريح، فقط على النداء
export default handler