import fetch from 'node-fetch'

// ✅ جيب الـ cookies والـ CSRF token من الموقع
const getSession = async () => {
  const res = await fetch('https://spotmate.online/en1', {
    headers: {
      'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36',
      'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
      'accept-language': 'ar-EG,ar;q=0.9,en-US;q=0.8,en;q=0.7',
    }
  })

  const html    = await res.text()
  const cookies = res.headers.raw()['set-cookie'] || []
  const cookieStr = cookies.map(c => c.split(';')[0]).join('; ')

  // استخراج الـ CSRF token من الـ HTML
  const csrfMatch = html.match(/"csrfToken"\s*:\s*"([^"]+)"/) ||
                    html.match(/meta.*csrf-token.*content="([^"]+)"/) ||
                    html.match(/csrf[_-]token['"]\s*:\s*['"]([^'"]+)/)

  const xsrfMatch = cookies.find(c => c.startsWith('XSRF-TOKEN='))
  let xsrf = ''
  if (xsrfMatch) {
    xsrf = decodeURIComponent(xsrfMatch.split('=')[1].split(';')[0])
  }

  const csrfToken = csrfMatch?.[1] || xsrf

  return { cookieStr, csrfToken }
}

let handler = async (m, { conn, text }) => {
  // استخراج الـ URL من النص
  const spotifyUrl = text?.trim()
  if (!spotifyUrl || !spotifyUrl.includes('spotify.com/track/')) {
    return m.reply(`╭─「 🎵 سبوتيفاي 」
│
│  ⚠️ ضيف لينك الأغنية!
│
│  📌 مثال:
│  .سبوتي https://open.spotify.com/track/xxx
│
╰──────────────`)
  }

  await m.react('⏳')
  await m.reply('🎵 جاري تحميل الأغنية...')

  try {
    // ✅ خطوة 1: جيب الـ session
    const { cookieStr, csrfToken } = await getSession()

    const headers = {
      'authority': 'spotmate.online',
      'accept': '*/*',
      'accept-language': 'ar-EG,ar;q=0.9,en-US;q=0.8,en;q=0.7',
      'content-type': 'application/json',
      'cookie': cookieStr,
      'origin': 'https://spotmate.online',
      'referer': 'https://spotmate.online/en1',
      'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36',
      'x-csrf-token': csrfToken,
    }

    // ✅ خطوة 2: جيب بيانات الأغنية
    const trackRes = await fetch('https://spotmate.online/getTrackData', {
      method: 'POST',
      headers,
      body: JSON.stringify({ spotify_url: spotifyUrl })
    })

    const trackData = await trackRes.json()
    console.log('[Spotify] Track data:', JSON.stringify(trackData).slice(0, 200))

    const title    = trackData?.name || trackData?.title || 'أغنية'
    const artist   = trackData?.artists?.[0]?.name || trackData?.artist || ''
    const duration = trackData?.duration_ms
      ? `${Math.floor(trackData.duration_ms / 60000)}:${String(Math.floor((trackData.duration_ms % 60000) / 1000)).padStart(2, '0')}`
      : ''
    const thumb    = trackData?.album?.images?.[0]?.url || trackData?.image || ''

    // ✅ خطوة 3: جيب رابط التحميل
    const cleanUrl = spotifyUrl.split('?')[0]
    const convertRes = await fetch('https://spotmate.online/convert', {
      method: 'POST',
      headers,
      body: JSON.stringify({ urls: cleanUrl })
    })

    const convertData = await convertRes.json()
    console.log('[Spotify] Convert data:', JSON.stringify(convertData).slice(0, 300))

    const downloadUrl = convertData?.link ||
                        convertData?.download_link ||
                        convertData?.url ||
                        convertData?.data?.link ||
                        convertData?.data?.url ||
                        Object.values(convertData || {}).find(v => typeof v === 'string' && v.startsWith('http'))

    if (!downloadUrl) {
      await m.react('❌')
      return m.reply('❌ مش قادر أجيب رابط التحميل!')
    }

    // ✅ خطوة 4: تحميل الـ MP3
    const audioRes = await fetch(downloadUrl, {
      headers: {
        'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36',
        'referer': 'https://spotmate.online/',
      }
    })

    const audioBuffer = Buffer.from(await audioRes.arrayBuffer())

    // ✅ تحميل الصورة لو موجودة
    let thumbBuffer = null
    if (thumb) {
      const thumbRes = await fetch(thumb).catch(() => null)
      if (thumbRes?.ok) thumbBuffer = Buffer.from(await thumbRes.arrayBuffer())
    }

    // ✅ إرسال الأغنية
    await conn.sendMessage(m.chat, {
      audio: audioBuffer,
      mimetype: 'audio/mpeg',
      fileName: `${title} - ${artist}.mp3`,
      contextInfo: thumbBuffer ? {
        externalAdReply: {
          title: title,
          body: artist,
          thumbnailUrl: thumb,
          mediaType: 1,
          renderLargerThumbnail: true
        }
      } : undefined
    }, { quoted: m })

    await m.react('✅')

  } catch (e) {
    console.error('[Spotify]', e.message)
    await m.react('❌')
    m.reply(`❌ خطأ: ${e.message}`)
  }
}

handler.help = ['سبوتي']
handler.tags = ['download']
handler.command = ['سبوتي', 'spotify', 'سبوتيفاي']

export default handler