// plugins/satoru-audio-fixed.js  (نسخة كاملة ومحسّنة: تحميل من رابط مع فحوصات متعددة)
import fs from "fs";
import fsPromises from "fs/promises";
import path from "path";
import { fileURLToPath } from "url";
import crypto from "crypto";
import fetch from "node-fetch";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const { proto, generateWAMessageFromContent, generateWAMessageContent } = (await import("@whiskeysockets/baileys")).default;

// ======= تعديل هنا حسب حاجتك =======
const AUDIO_URL = "https://files.catbox.moe/baepko.mp3"; // رابط الملف الصوتي (اضبطه)
const THUMB_URL = "https://files.catbox.moe/5gqyp0.jpg"; // صورة
const SIGNATURE = "⛩️سوكونا⛩️";
// ======= إعدادات الأداء =======
const TMP_DIR = path.join(process.cwd(), "tmp_eidit");
if (!fs.existsSync(TMP_DIR)) fs.mkdirSync(TMP_DIR, { recursive: true });

const MIN_VALID_BYTES = 1024;        // أقل من كده غالبًا تالف
const FETCH_TIMEOUT_MS = 30_000;     // 30s
const MAX_BYTES_SAFE = 200 * 1024 * 1024; // 200MB safety cap (ضبط لو تريد أكبر)
const HEAD_TIMEOUT_MS = 8_000;       // 8s

// ---------- Helpers ----------
function sleep(ms){ return new Promise(r=>setTimeout(r,ms)); }

async function quickHeadCheck(url) {
  try {
    const controller = new AbortController();
    const id = setTimeout(()=> controller.abort(), HEAD_TIMEOUT_MS);
    const res = await fetch(url, { method: "HEAD", redirect: "follow", signal: controller.signal });
    clearTimeout(id);
    if (!res) return { ok:false };
    const ct = (res.headers.get("content-type") || "").toLowerCase();
    const cl = res.headers.get("content-length");
    return { ok:true, contentType: ct, contentLength: cl ? Number(cl) : null, status: res.status };
  } catch (e) {
    return { ok:false, error: e.message || String(e) };
  }
}

/**
 * تحميل إلى ملف مؤقت مع فحوصات:
 * - HEAD أولاً (إن أمكن) للتأكد من content-type / content-length
 * - تحميل stream إلى ملف مؤقت مع timeout
 * - فحص أول حُزء من المحتوى للتأكد أنه ليس HTML
 * - إرجاع Buffer الناتج
 */
async function fetchAudioToBuffer(url, { timeout = FETCH_TIMEOUT_MS, maxBytes = MAX_BYTES_SAFE } = {}) {
  // HEAD check (مفيد لاكتشاف HTML أو redirect)
  const head = await quickHeadCheck(url);
  if (head.ok) {
    if (!head.contentType.includes("audio") && !head.contentType.includes("mpeg") && !head.contentType.includes("octet-stream")) {
      // ليس بالضرورة قاتل — لكن غالباً يدل على صفحة HTML أو خطأ
      throw new Error("الرابط لا يعِد نوع صوتي صالح (Content-Type: " + head.contentType + ").");
    }
    if (head.contentLength && head.contentLength > maxBytes) {
      throw new Error("حجم الملف أكبر من الحد المسموح: " + head.contentLength + " bytes.");
    }
  } // إن فشل HEAD سنتابع المحاولة لأن بعض الخوادم تحظر HEAD.

  // تحميل stream إلى ملف مؤقت
  const tmpName = "aud_" + crypto.randomBytes(6).toString("hex") + ".tmp";
  const tmpPath = path.join(TMP_DIR, tmpName);

  const controller = new AbortController();
  const timer = setTimeout(()=> controller.abort(), timeout);

  let res;
  try {
    res = await fetch(url, { method: "GET", redirect: "follow", signal: controller.signal });
  } catch (e) {
    clearTimeout(timer);
    throw new Error("فشل الاتصال بالمصدر: " + (e.message || e));
  }
  clearTimeout(timer);

  if (!res.ok) {
    const ct2 = res.headers.get("content-type") || "";
    // بعض الخوادم تعطي 403/503 للطلبات من سيرفرات أخرى
    if (!ct2.includes("audio") && !ct2.includes("mpeg") && !ct2.includes("octet-stream")) {
      throw new Error("الاستجابة ليست ملف صوتي (HTTP " + res.status + ", content-type: " + ct2 + ").");
    }
  }

  // تحقق حجم الرؤوس إن وُجد
  const contentLength = res.headers.get("content-length");
  if (contentLength && Number(contentLength) > maxBytes) {
    throw new Error("حجم الملف الموجود على المضيف أكبر من الحد المسموح (" + contentLength + " bytes).");
  }

  // Stream إلى ملف
  const out = fs.createWriteStream(tmpPath);
  try {
    await new Promise((resolve, reject) => {
      res.body.pipe(out);
      res.body.on("error", err => {
        out.close();
        reject(err);
      });
      out.on("finish", resolve);
      out.on("error", err => {
        reject(err);
      });
    });
  } catch (e) {
    try { if (fs.existsSync(tmpPath)) fs.unlinkSync(tmpPath); } catch(_) {}
    throw new Error("فشل تنزيل الملف أو انقطع الاتصال: " + (e.message || e));
  }

  // فحص الملف الذي نزل
  let stat;
  try {
    stat = fs.statSync(tmpPath);
  } catch (e) {
    try { fs.unlinkSync(tmpPath); } catch(_) {}
    throw new Error("فشل الوصول للملف الذي تم تنزيله.");
  }
  if (stat.size < MIN_VALID_BYTES) {
    try { fs.unlinkSync(tmpPath); } catch(_) {}
    throw new Error("الملف الذي تم تنزيله صغير جدًا أو تالف (size=" + stat.size + ").");
  }
  if (stat.size > maxBytes) {
    try { fs.unlinkSync(tmpPath); } catch(_) {}
    throw new Error("الملف الذي تم تنزيله أكبر من الحد المسموح (" + stat.size + " bytes).");
  }

  // اقرأ أول 1KB للتحقق إن لم تكن صفحة HTML
  const fd = fs.openSync(tmpPath, "r");
  const headerBuf = Buffer.alloc(Math.min(1024, stat.size));
  fs.readSync(fd, headerBuf, 0, headerBuf.length, 0);
  fs.closeSync(fd);
  const headStr = headerBuf.toString("utf8").toLowerCase();
  if (headStr.includes("<html") || headStr.includes("<!doctype html") || headStr.includes("content-type: text/html") || headStr.includes("<script")) {
    try { fs.unlinkSync(tmpPath); } catch(_) {}
    throw new Error("المصدر أعاد صفحة HTML أو محتوى غير صوتي.");
  }

  // اقرأ كله كـ Buffer (يمكنك إرسال كـ stream بدل Buffer لو تريد)
  let finalBuf;
  try {
    finalBuf = fs.readFileSync(tmpPath);
  } finally {
    // تنظيف الملف المؤقت فوراً
    try { fs.unlinkSync(tmpPath); } catch(_) {}
  }
  return finalBuf;
}

// fetch thumbnail buffer (هامشي هادئ — إن فشل نستمر)
async function fetchThumbnailBuffer(url) {
  try {
    const ctrl = new AbortController();
    const id = setTimeout(()=> ctrl.abort(), 8_000);
    const res = await fetch(url, { signal: ctrl.signal, redirect: "follow" });
    clearTimeout(id);
    if (!res.ok) return null;
    const ab = await res.arrayBuffer();
    return Buffer.from(ab);
  } catch (e) {
    return null;
  }
}

// ---------- Main handler ----------
let handler = async (m, { conn, text }) => {
  try {
    const body = (m.text || text || "").trim();
    const invoked = /^\.?ساتورو(?:\s+.*)?$/i.test(body);
    if (!invoked) return;

    // رسالة انتظار سريعة
    try { await conn.sendMessage(m.chat, { text: "لقد ايقظت الملك " }, { quoted: m }); } catch (e) {}

    // 1) حاول الإرسال كـ remote audio URL أولاً (WhatsApp يقوم بالـ fetch)
    const captionText = (body.replace(/^\.?ساتورو\s*/i, "").trim() || "⚡ سكونا حاضر.") + "\n\n" + SIGNATURE;
    try {
      const opts = {}; // لا رفع هنا
      const { audioMessage } = await generateWAMessageContent({ audio: { url: AUDIO_URL }, caption: captionText }, opts);
      const pkg = generateWAMessageFromContent(m.chat, { audioMessage }, { quoted: m });
      await conn.relayMessage(m.chat, pkg.message, { messageId: pkg.key.id });
      return;
    } catch (errRemote) {
      // لو فشل، نتابع إلى تنزيل الملف وإرساله ourselves
      console.warn("remote send failed:", errRemote && (errRemote.message || errRemote));
    }

    // 2) محاولة تحميل الملف كـ buffer مع فحوصات قوية
    let buf;
    try {
      buf = await fetchAudioToBuffer(AUDIO_URL, { timeout: FETCH_TIMEOUT_MS, maxBytes: MAX_BYTES_SAFE });
    } catch (e) {
      console.error("fetchAudioToBuffer failed:", e && (e.message || e));
      return await conn.sendMessage(m.chat, { text:
        "❌ هذا المقطع الصوتي غير متوفر لوجود خلل ما في الملف الصوتي أو المضيف يمنع التحميل.\nالخطأ: " + (e && e.message ? e.message : "فشل التحميل")
      }, { quoted: m });
    }

    // 3) جلب الصورة المصغّرة إن أمكن
    let thumbBuf = null;
    try { thumbBuf = await fetchThumbnailBuffer(THUMB_URL); } catch(_) { thumbBuf = null; }

    // 4) إرسال كـ voice note (ptt)
    try {
      await conn.sendMessage(m.chat, {
        audio: buf,
        mimetype: "audio/mpeg",
        fileName: "phase.mp3",
        ptt: false,
        caption: captionText,
        contextInfo: {
          externalAdReply: {
            title: "⛩️سوكونا⛩️",
            body: "⚡ استجابة صوتية",
            thumbnail: thumbBuf || undefined,
            mediaType: 1,
            renderLargerThumbnail: !!thumbBuf,
            mediaUrl: "https://wa.me/201002804195",
            sourceUrl: "https://wa.me/201002804195",
          },
        },
      }, { quoted: m });

      return;
    } catch (e) {
      console.warn("sending as ptt failed:", e && (e.message || e));
      // fallback: try to send as document
      try {
        await conn.sendMessage(m.chat, {
          document: buf,
          fileName: "phase.mp3",
          mimetype: "audio/mpeg",
          caption: captionText,
          contextInfo: {
            externalAdReply: {
              title: "⛩️سوكونا⛩️",
              body: "⚡ ملك اللعنات",
              thumbnail: thumbBuf || undefined,
              mediaType: 1,
              renderLargerThumbnail: !!thumbBuf,
              mediaUrl: "https://wa.me/201002804195",
              sourceUrl: "https://wa.me/201002804195",
            },
          },
        }, { quoted: m });
        return;
      } catch (ee) {
        console.error("sending as document also failed:", ee && (ee.message || ee));
        return await conn.sendMessage(m.chat, { text:
          "❌ فشل إرسال المقطع الصوتي بعد تحميله. " + (ee && ee.message ? ee.message : "")
        }, { quoted: m });
      }
    }

  } catch (err) {
    console.error("ساتورو handler unexpected:", err && (err.stack || err.message || err));
    try { await conn.sendMessage(m.chat, { text: `❌ حدث خطأ غير متوقع: ${err && err.message ? err.message : String(err)}` }, { quoted: m }); } catch (_) {}
  }
};

handler.help = ["سوكونا <نص>"];
handler.tags = ["fun"];
handler.command = [/^\.?سوكونا(?:\s+.*)?$/i];

export default handler;